<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

include 'koneksi.php';

$id_user = $_SESSION['id_user'];
$result = $koneksi->query("SELECT * FROM user WHERE id = '$id_user'");
$userData = $result->fetch_assoc();

if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $hp = $_POST['hp'];
    $alamat = $_POST['alamat'];

    // kalau password kosong, tetap pakai yang lama
    $password = !empty($_POST['password']) ? $_POST['password'] : $userData['password'];

    $sql = "UPDATE user SET 
                nama='$nama', 
                email='$email', 
                username='$username', 
                password='$password', 
                hp='$hp', 
                alamat='$alamat'
            WHERE id='$id_user'";

    if ($koneksi->query($sql)) {
        // update session biar langsung kebaca di index.php
        $_SESSION['user'] = $username;
    } else {
        echo "Error: " . $koneksi->error;
    }
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Profil</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<?php include 'navbar.php'; ?>

<div class="container mt-5">
  <div class="row">
    <!-- Kolom Edit Profil -->
    <div class="col-md-6">
      <div class="card shadow-lg rounded-4 mb-4">
        <div class="card-header bg-primary text-white text-center rounded-top-4">
          <h4 class="mb-0">Edit Profil</h4>
        </div>
        <div class="card-body">
          <form method="post">
            <div class="mb-3">
              <label class="form-label">Nama</label>
              <input type="text" name="nama" class="form-control" value="<?= $userData['nama'] ?>">
            </div>

            <div class="mb-3">
              <label class="form-label">Username</label>
              <input type="text" name="username" class="form-control" value="<?= $userData['username'] ?>">
            </div>

            <div class="mb-3">
              <label class="form-label">Email</label>
              <input type="email" name="email" class="form-control" value="<?= $userData['email'] ?>">
            </div>

            <div class="mb-3">
              <label class="form-label">No HP</label>
              <input type="text" name="hp" class="form-control" value="<?= $userData['hp'] ?>">
            </div>

            <div class="mb-3">
              <label class="form-label">Alamat</label>
              <textarea name="alamat" class="form-control" rows="3"><?= $userData['alamat'] ?></textarea>
            </div>

            <div class="mb-3">
              <label class="form-label">Password (Opsional)</label>
              <input type="password" name="password" class="form-control" placeholder="Kosongkan jika tidak ingin ganti">
            </div>

            <div class="d-grid">
              <button type="submit" name="update" class="btn btn-primary">Update Profil</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <!-- Kolom History Transaksi -->
    <div class="col-md-6">
      <div class="card shadow-lg rounded-4">
        <div class="card-header bg-success text-white text-center rounded-top-4">
          <h4 class="mb-0">History Transaksi</h4>
        </div>
        <div class="card-body">
          <table class="table table-bordered table-striped">
            <thead class="table-success">
              <tr>
                <th>No</th>
                <th>Tanggal</th>
                <th>Jumlah Barang</th>
                <th>Total Harga</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $no = 1;
              $sql_histori = "
                SELECT t.id_transaksi, t.tanggal, t.total_harga, SUM(d.jumlah) AS total_barang
                FROM transaksi t
                LEFT JOIN detail d ON t.id_transaksi = d.id_transaksi
                WHERE t.id_pelanggan = '$id_user'
                GROUP BY t.id_transaksi, t.tanggal, t.total_harga
                ORDER BY t.tanggal DESC
              ";
              $q_histori = mysqli_query($koneksi, $sql_histori);

              if (mysqli_num_rows($q_histori) > 0) {
                  while ($row = mysqli_fetch_assoc($q_histori)) {
                      echo "<tr>
                              <td>".$no++."</td>
                              <td>".$row['tanggal']."</td>
                              <td>".$row['total_barang']."</td>
                              <td>Rp ".number_format($row['total_harga'])."</td>
                              <td>
                                <a href='invoice.php?id=".$row['id_transaksi']."' class='btn btn-sm btn-info'>Lihat</a>
                              </td>
                            </tr>";
                  }
              } else {
                  echo "<tr><td colspan='5' class='text-center'>Belum ada transaksi</td></tr>";
              }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
