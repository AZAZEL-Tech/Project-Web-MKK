<nav class="navbar navbar-expand-lg shadow-sm sticky-top" style="background-color: grey;">
  <div class="container">
    <!-- Logo -->
    <a class="navbar-brand text-white fw-bold" href="#">
      <img src="aset/img/logo.png" alt="Logo" style="height:40px;">
    </a>

    <!-- Toggle (mobile view) -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menu -->
    <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
      <ul class="navbar-nav">
        <!-- Home -->
        <li class="nav-item">
          <a class="nav-link active text-white fw-semibold" href="index.php">Home</a>
        </li>

        <!-- Dropdown Kategori -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle text-white fw-semibold" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Kategori
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Rice</a></li>
            <li><a class="dropdown-item" href="#">Seafood</a></li>
            <li><a class="dropdown-item" href="#">Animal</a></li>
            <li><a class="dropdown-item" href="#">Minuman</a></li>
          </ul>
        </li>

        <!-- Keranjang -->
        <li class="nav-item">
          <a class="nav-link text-white" href="cart.php">
            <i class="bi bi-cart fs-5"></i>
          </a>
        </li>
      </ul>

      <!-- Profil -->
      <div class="nav-links ms-3 text-end">
        <?php if (isset($_SESSION['user'])): ?>
          <a href="profile.php" class="btn btn-light rounded-circle">
            <i class="bi bi-person-circle" style="font-size: 1.5rem;"></i>
          </a>
        <?php else: ?>
          <!-- Kalau belum login arahkan ke login.php -->
          <a href="login.php" class="btn btn-light rounded-circle">
            <i class="bi bi-person-circle" style="font-size: 1.5rem;"></i>
          </a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
