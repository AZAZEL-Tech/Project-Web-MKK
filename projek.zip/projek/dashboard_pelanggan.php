<?php
session_start();

// if (!isset($_SESSION['user'])) {
//     header("Location: login.php");
//     exit();
// }
include 'koneksi.php';

// Ambil daftar kategori unik dari database
$kategori_result = $koneksi->query("SELECT DISTINCT id_kategori FROM produk");


$id_user = $_SESSION['id_user'];
$result = $koneksi->query("SELECT * FROM user WHERE id = '$id_user'");
$userData = $result->fetch_assoc();


$showAlert = false;


if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $hp = $_POST['hp'];
    $alamat = $_POST['alamat'];
    $role = $_POST['user']; 

    //ganti gambarrrrrrrrrr 
     if ($_FILES['gambar']['name']) {
        $gambar = $_FILES['gambar']['name'];
        $tmp = $_FILES['gambar']['tmp_name'];
        move_uploaded_file($tmp, "img/$gambar");
        $koneksi->query("UPDATE user SET nama='$nama', email='$email', username='$username', password='$password', hp='$hp', alamat='$alamat', gambar='$gambar' WHERE id=$id");
      }else {
        $koneksi->query("UPDATE user SET nama='$nama', email='$email', username='$username', password='$password', hp='$hp', alamat='$alamat', gambar='$gambar' WHERE id=$id");
}

 $showAlert = true; // set untuk menampilkan SweetAlert

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Pelanggan - Rojidun Kitchen</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #ffffffff;
      color: #333;
    }

    .navbar {
      background-color: #ff8800ff;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    .navbar-brand {
      font-weight: 600;
      color: #8f9ef4;
    }

    .welcome {
      text-align: center;
      margin: 30px 0 10px;
      color: #000000ff;
    }

    .card {
      border: none;
      border-radius: 15px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.1);
      transition: transform 0.3s ease;
    }

    .card:hover {
      transform: translateY(-5px);
    }

    .card-title {
      font-size: 18px;
      font-weight: bold;
      color: #ff8800ff;
    }

    .btn-primary {
      background-color: #ff7300ff;
      border: none;
    }

    .btn-primary:hover {
      background-color: #6f85e4;
    }

    footer {
      background-color: #000000ff;
      color: white;
      text-align: center;
      padding: 20px 0;
      margin-top: 50px;
    }

    /* === Sidebar Profil === */
    .profile-icon {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      cursor: pointer;
      transition: transform 0.2s;
    }
    .profile-icon:hover {
      transform: scale(1.1);
    }

    .sidebar {
      height: 100%;
      width: 0;
      position: fixed;
      top: 0;
      right: 0;
      background-color: #fff;
      box-shadow: -4px 0 12px rgba(0,0,0,0.2);
      overflow-x: hidden;
      transition: 0.4s;
      padding-top: 60px;
      z-index: 9999;
    }

    .sidebar.open {
  width: 340px; /* lebih lebar biar lega */
}

.nav-tabs .nav-link {
  color: #4b49ac;
  border: none;
}
.nav-tabs .nav-link.active {
  background-color: #8f9ef4;
  color: #fff;
  border-radius: 20px;
}


    .sidebar-content {
      padding: 20px;
    }

    .sidebar h4 {
      color: #4b49ac;
      font-weight: bold;
    }

    .sidebar .closebtn {
      position: absolute;
      top: 15px;
      right: 20px;
      font-size: 30px;
      cursor: pointer;
      color: #4b49ac;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container">
    <a class="navbar-brand d-flex align-items-center" href="#">
      <img src="aset/img/logo.png" alt="Logo" width="40" class="me-2 rounded">
      Rojidun Kitchen
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMenu" aria-controls="navbarMenu" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarMenu">
      <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Beranda</a>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Kategori
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="#">Rice</a></li>
            <li><a class="dropdown-item" href="#">Seafood</a></li>
            <li><a class="dropdown-item" href="#">Animal</a></li>
            <li><a class="dropdown-item" href="#">Minuman</a></li>
          </ul>
        </li>
      </ul>
      <!-- Profile Icon di kanan navbar -->
      <img src="aset/img/profil.jpeg" alt="Profil" class="profile-icon ms-lg-3" onclick="toggleSidebar()">
    </div>
  </div>
</nav>

<!-- Sidebar Profil -->
<div id="sidebar" class="sidebar">
  <span class="closebtn" onclick="toggleSidebar()">&times;</span>
  <div class="sidebar-content text-center">

    <!-- Foto Profil -->
    <img src="aset/img/profil.jpeg" alt="Profil" 
         class="rounded-circle mb-3" 
         style="width: 90px; height: 90px; object-fit: cover; border: 3px solid #8f9ef4;">

    <!-- Tab Navigasi -->
    <ul class="nav nav-tabs justify-content-center mb-3" id="profileTabs">
      <li class="nav-item">
        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#info">Profil</button>
      </li>
      <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#edit">Edit</button>
      </li>
      <li class="nav-item">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#settings">Pengaturan</button>
      </li>
    </ul>

    <!-- Isi Tab -->
    <div class="tab-content text-start">

      <!-- Tab Profil -->
      <div class="tab-pane fade show active" id="info">
        <h5 class="text-center text-primary">Profil Saya</h5>
        <p><strong>Username:</strong> <?= $_SESSION["user"] ?></p>
        <p><strong>Email:</strong> <?= $_SESSION["email"] ?></p>
      </div>

      <!-- Tab Edit -->
      <div class="tab-pane fade" id="edit">
        <h5 class="text-center text-primary">Edit Profil</h5>
        <form action="update_profile.php" method="POST" enctype="multipart/form-data">
          <div class="mb-2">
            <label class="form-label">Nama</label>
            <input type="text" name="nama" class="form-control form-control-sm" value="<?= $_SESSION["nama"] ?? '' ?>">
          </div>
          <div class="mb-2">
            <label class="form-label">Alamat</label>
            <input type="text" name="alamat" class="form-control form-control-sm" value="<?= $userData["alamat"] ?>">
          </div>
          <div class="mb-2">
            <label class="form-label">No. Handphone</label>
           <input type="number" name="hp" class="form-control form-control-sm" value="<?= $userData["hp"] ?>">
          </div>
          <div class="mb-2">
            <label class="form-label">Foto Profil</label>
            <input type="file" name="gambar" class="form-control form-control-sm">
          </div>
          <button type="submit" class="btn btn-primary btn-sm w-100">Simpan</button>
        </form>
      </div>

      <?php if ($showAlert): ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    Swal.fire({
        icon: 'success',
        title: 'Berhasil!',
        text: 'Profil berhasil di edit',
        confirmButtonColor: '#198754'
    }).then(() => {
        window.location.href = "dashboard_pelanggan.php";
    });
});
</script>
<?php endif; ?>

      <!-- Tab Settings -->
      <div class="tab-pane fade" id="settings">
        <h5 class="text-center text-primary">Pengaturan</h5>
        <div class="form-check form-switch">
          <input class="form-check-input" type="checkbox" id="darkModeSwitch">
          <label class="form-check-label" for="darkModeSwitch">Mode Gelap</label>
        </div>
      </div>

    </div>

    <!-- Tombol Logout -->
    <form action="dashboard_pelanggan.php" method="POST" class="mt-3">
      <button type="submit" name="logout" class="btn btn-danger btn-sm w-100">Logout</button>
    </form>
  </div>
</div>


<h3 class="welcome">Selamat Datang, <?= $_SESSION["user"] ?>!</h3>

<div class="container mt-4">
  <?php while ($kategori_row = $kategori_result->fetch_assoc()): ?>
    <h4 class="mb-3"><?= $kategori_row['id_kategori'] ?></h4>
    <div class="row g-4 mb-5">
      <?php
      $produk_result = $koneksi->query("SELECT * FROM produk WHERE id_kategori = '".$kategori_row['id_kategori']."'");
      while ($row = $produk_result->fetch_assoc()):
      ?>
        <div class="col-md-4">
          <div class="card h-100">
            <img src="img/<?= $row['gambar'] ?>" class="card-img-top" alt="<?= $row['nama_produk'] ?>">
            <div class="card-body">
              <h5 class="card-title"><?= $row['nama_produk'] ?></h5>
              <p class="card-text">Rp<?= number_format($row['harga']) ?></p>
              <p class="card-text">Stok: <?= number_format($row['stok']) ?></p>
              <p class="card-text"><?= $row['deskripsi'] ?></p>
              <a href="detail.php?id=<?= $row['id'] ?>" class="btn btn-primary">Beli Sekarang</a>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  <?php endwhile; ?>
</div>

<footer>
  <div class="container">
    <hr class="border-white opacity-25">
    <p class="mb-0">Anindia Kitchen adalah platform jual beli kue yang aman, praktis, dan terpercaya berbasis website.</p>
  </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
<script>
  AOS.init({ duration: 1000, once: true });

  function toggleSidebar() {
    document.getElementById("sidebar").classList.toggle("open");
  }
</script>

<?php
if (isset($_POST['logout'])) {
  session_unset();
  session_destroy();
  header('Location: index.php');
  exit();
}
?>
</body>
</html>