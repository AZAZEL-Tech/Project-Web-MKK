<?php
session_start();
if (!isset($_SESSION['id_user'])) {
    header('location:login.php');
    exit;
}

$koneksi = mysqli_connect("localhost", "root", "", "kichen");
$id_user = $_SESSION['id_user'];

// Tambah produk ke keranjang
if (isset($_POST["add"])) {
    $id_produk = $_GET["id"];

    if (isset($_SESSION["cart"][$id_produk])) {
        $_SESSION["cart"][$id_produk]['jumlah'] += $_POST["jumlah"];
    } else {
        $_SESSION["cart"][$id_produk] = array(
            'id'     => $id_produk,
            'nama'   => $_POST["hidden_nama"],
            'harga'  => $_POST["hidden_harga"],
            'gambar' => $_POST["hidden_gambar"],
            'jumlah' => $_POST["jumlah"]
        );
    }

    echo '<script>window.location="cart.php"</script>';
}

// Aksi hapus atau beli
if (isset($_GET["aksi"])) {
    if ($_GET["aksi"] == "hapus") {
        $id_produk = $_GET["id"];
        if (isset($_SESSION["cart"][$id_produk])) {
            unset($_SESSION["cart"][$id_produk]);
            header("Location: cart.php?status=deleted");
            exit;
        }
    } elseif ($_GET["aksi"] == "beli") {
        $total = 0;
        foreach ($_SESSION["cart"] as $value) {
            $total += ($value["jumlah"] * $value["harga"]);
        }

        // Simpan transaksi utama
        $query = mysqli_query(
            $koneksi,
            "INSERT INTO transaksi(tanggal, id_pelanggan, total_harga)
             VALUES ('" . date("Y-m-d") . "', '$id_user', '$total')"
        ) or die("Error insert transaksi: " . mysqli_error($koneksi));
        $id_transaksi = mysqli_insert_id($koneksi);

        // Simpan detail produk
        foreach ($_SESSION["cart"] as $value) {
            $id_produk = $value['id'];
            $jumlah    = $value['jumlah'];
            $sql = "INSERT INTO detail(id_transaksi, id_produk, jumlah)
                    VALUES ('$id_transaksi', '$id_produk', '$jumlah')";
            mysqli_query($koneksi, $sql);
        }

        unset($_SESSION["cart"]);
echo '<script>window.location="invoice.php?id=' . $id_transaksi . '"</script>';
exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Keranjang Belanja</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body class="bg-light">
<?php include 'navbar.php'; ?>
<div class="container py-5">
    <div class="card shadow-lg border-0 rounded-4">
        <div class="card-header bg-dark text-white text-center rounded-top-4">
            <h3><i class="bi bi-cart4"></i> Keranjang Belanja</h3>
        </div>
        <div class="card-body p-4">

            <?php if (!empty($_SESSION["cart"])) { ?>
                <div class="table-responsive">
                    <table class="table table-bordered align-middle text-center">
                        <thead class="table-dark">
                            <tr>
                                <th>Produk</th>
                                <th>Jumlah</th>
                                <th>Harga</th>
                                <th>Total Harga</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $total = 0;
                        foreach ($_SESSION["cart"] as $key => $value) {
                        ?>
                            <tr>
                                <td class="text-start">
                                    <img src="img/<?= $value["gambar"] ?>" class="rounded me-2" style="height:80px;">
                                    <strong><?= $value["nama"] ?></strong>
                                </td>
                                <td><?= $value["jumlah"] ?></td>
                                <td>Rp <?= number_format($value["harga"]) ?></td>
                                <td>Rp <?= number_format($value["jumlah"] * $value["harga"], 2) ?></td>
                                <td>
                                    <a href="javascript:void(0);" 
                                       onclick="confirmDelete('cart.php?aksi=hapus&id=<?= $value['id']; ?>')" 
                                       class="btn btn-sm btn-danger">
                                        <i class="bi bi-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php
                            $total += ($value["jumlah"] * $value["harga"]);
                        }
                        ?>
                            <tr class="table-secondary">
                                <td colspan="3" class="text-end"><strong>Grand Total :</strong></td>
                                <td colspan="2"><strong>Rp <?= number_format($total, 2) ?></strong></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="d-flex justify-content-between">
                    <a href="index.php" class="btn btn-outline-secondary">
                        ← Lanjut Belanja
                    </a>
                    <a href="cart.php?aksi=beli" class="btn btn-success btn-lg">
                        <i class="bi bi-cash-coin"></i> Beli Sekarang
                    </a>
                </div>

            <?php } else { ?>
                <div class="text-center py-5">
                    <h5 class="text-muted">Keranjang Anda kosong</h5>
                    <a href="index.php" class="btn btn-primary mt-3">
                        <i class="bi bi-shop"></i> Belanja Sekarang
                    </a>
                </div>
            <?php } ?>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function confirmDelete(url) {
    Swal.fire({
        title: 'Yakin mau hapus?',
        text: "Produk ini akan dihapus dari keranjang!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#6c757d',
        confirmButtonText: 'Ya, hapus',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = url;
        }
    });
}
</script>

<?php if (isset($_GET['status']) && $_GET['status'] == 'deleted'): ?>
<script>
Swal.fire({
    icon: 'success',
    title: 'Dihapus!',
    text: 'Produk berhasil dihapus dari keranjang.',
    timer: 2000,
    showConfirmButton: false
});
</script>
<?php endif; ?>

</body>
</html>
