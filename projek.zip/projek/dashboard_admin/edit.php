<?php
include 'koneksi.php';
include 'sidebar.php';

// pastikan ada id produk di url
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die("ID produk tidak ditemukan!");
}
$id = intval($_GET['id']);

// ambil data produk berdasarkan id
$data = $koneksi->query("SELECT * FROM produk WHERE id_produk = $id")->fetch_assoc();
if (!$data) {
    die("Produk tidak ditemukan!");
}

if (isset($_POST['update'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $kategori = $_POST['kategori'];
    $deskripsi = $_POST['deskripsi'];

    // jika ganti gambar
    if (!empty($_FILES['gambar']['name'])) {
        $gambar = time() . "_" . $_FILES['gambar']['name']; // kasih timestamp biar unik
        $tmp = $_FILES['gambar']['tmp_name'];
        move_uploaded_file($tmp, "img/$gambar");

        $koneksi->query("UPDATE produk 
            SET nama_produk='$nama', 
                harga='$harga', 
                stok='$stok', 
                kategori='$kategori', 
                deskripsi='$deskripsi', 
                gambar='$gambar' 
            WHERE id=$id");
    } else {
        $koneksi->query("UPDATE produk 
            SET nama_produk='$nama', 
                harga='$harga',  
                stok='$stok',
                id_kategori='$kategori', 
                deskripsi='$deskripsi' 
            WHERE id_produk=$id");
    }

    echo "<script>
            alert('Produk berhasil diperbarui!');
            window.location.href = 'produk.php';
          </script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Produk</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .main {
      margin-left: 220px; /* supaya tidak ketiban sidebar */
      padding: 30px;
      background: #f8f9fa;
      min-height: 100vh;
    }
    .card {
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    .btn {
      border-radius: 8px;
    }
    .form-label {
      font-weight: bold;
    }
  </style>
</head>
<body>

<div class="main">
  <div class="container">
    <div class="card">
      <div class="card-header bg-dark text-white">
        <h4 class="mb-0">Edit Produk</h4>
      </div>
      <div class="card-body">
        <form method="post" enctype="multipart/form-data">
          <div class="mb-3">
            <label class="form-label">Nama Produk</label>
            <input type="text" name="nama" class="form-control" value="<?= $data['nama_produk'] ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Harga</label>
            <input type="number" name="harga" class="form-control" value="<?= $data['harga'] ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Stok</label>
            <input type="number" name="stok" class="form-control" value="<?= $data['stok'] ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Kategori</label>
            <input type="text" name="kategori" class="form-control" value="<?= $data['id_kategori'] ?>" required>
          </div>
          <div class="mb-3">
            <label class="form-label">Deskripsi</label>
            <textarea name="deskripsi" class="form-control" rows="4" required><?= $data['deskripsi'] ?></textarea>
          </div>
          <div class="mb-3">
            <label class="form-label">Gambar Saat Ini</label><br>
            <img src="img/<?= $data['gambar'] ?>" alt="gambar produk" class="img-thumbnail" style="max-width: 150px;">
          </div>
          <div class="mb-3">
            <label class="form-label">Ganti Gambar (jika perlu)</label>
            <input type="file" name="gambar" class="form-control">
          </div>
          <button type="submit" name="update" class="btn btn-success">Update</button>
          <a href="produk.php" class="btn btn-secondary">Kembali</a>
        </form>
      </div>
    </div>
  </div>
</div>
  <!-- ALERT SWEETALERT -->
  <?php if (isset($_GET['status'])): ?>
    <script>
      document.addEventListener("DOMContentLoaded", function() {
          <?php if ($_GET['status'] == 'edit'): ?>
              Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Produk berhasil ditambahkan', confirmButtonColor: '#28a745' });
          <?php elseif ($_GET['status'] == 'hapus'): ?>
              Swal.fire({ icon: 'warning', title: 'Dihapus!', text: 'Produk berhasil dihapus', confirmButtonColor: '#d33' });
          <?php endif; ?>
      });
    </script>
  <?php endif; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
