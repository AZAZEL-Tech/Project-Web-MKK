<?php
include 'koneksi.php';
include 'sidebar.php';

// ambil semua transaksi
$resultTransaksi = $koneksi->query("
    SELECT t.id_transaksi, t.tanggal, t.total_harga as total, u.nama 
    FROM transaksi t
    JOIN user u ON t.id_pelanggan = u.id
    ORDER BY t.id_transaksi DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Data Transaksi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .main {
      margin-left: 220px; /* biar ga ketiban sidebar */
      padding: 30px;
      background: #f9f9f9;
      min-height: 100vh;
    }
    .card {
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    table th {
      text-align: center;
      vertical-align: middle;
    }
    table td {
      vertical-align: middle;
    }
    .btn-primary {
      border-radius: 20px;
      padding: 5px 15px;
    }
  </style>
</head>
<body>
<div class="main">

  <div class="card">
    <div class="card-header bg-dark text-white">
      <h4 class="mb-0"> Data Transaksi</h4>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
          <thead class="table-dark text-center">
            <tr>
              <th>ID</th>
              <th>Tanggal</th>
              <th>Nama Pelanggan</th>
              <th>Total</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php while($row = mysqli_fetch_assoc($resultTransaksi)): ?>
            <tr>
              <td class="text-center"><?= $row['id_transaksi'] ?></td>
              <td class="text-center"><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td>
              <td><?= $row['nama'] ?></td>
              <td class="text-end">Rp <?= number_format($row['total'],0,',','.') ?></td>
              <td class="text-center">
                <a href="detail_transaksi.php?id=<?= $row['id_transaksi'] ?>" class="btn btn-primary btn-sm">
                  Detail
                </a>
              </td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>
</body>
</html>
