<?php
$current_page = basename($_SERVER['PHP_SELF']); // ambil nama file yang sedang dibuka
?>

<!-- Sidebar -->
<div class="sidebar bg-dark text-white p-3 position-fixed h-100" style="width:220px;">
  <div class="text-center mb-4">
    <img src="../aset/img/logo.png" alt="Logo" class="img-fluid mb-2" style="max-width:100px;">
    <h4>Admin Panel</h4>
  </div>
  <ul class="nav flex-column">
    <li class="nav-item">
      <a href="dashboard.php" 
         class="nav-link text-white <?= ($current_page == 'dashboard.php') ? 'active bg-primary rounded' : '' ?>">
         Dashboard
      </a>
    </li>
    <li class="nav-item">
      <a href="produk.php" 
         class="nav-link text-white <?= ($current_page == 'produk.php') ? 'active bg-primary rounded' : '' ?>">
         Produk
      </a>
    </li>
    <li class="nav-item">
      <a href="data_transaksi.php" 
         class="nav-link text-white <?= ($current_page == 'data_transaksi.php') ? 'active bg-primary rounded' : '' ?>">
         Transaksi
      </a>
    </li>
    <li class="nav-item">
      <a href="data_user.php" 
         class="nav-link text-white <?= ($current_page == 'data_user.php') ? 'active bg-primary rounded' : '' ?>">
         User
      </a>
    </li>
    <li class="nav-item">
      <a href="../logout.php" class="nav-link text-white">
        Logout
      </a>
    </li>
  </ul>
</div>

<style>
  .sidebar .nav-link {
    padding: 10px 15px;
    margin-bottom: 5px;
    transition: background 0.3s;
  }
  .sidebar .nav-link:hover {
    background: #495057;
    border-radius: 8px;
  }
  .sidebar .active {
    font-weight: bold;
  }
</style>
