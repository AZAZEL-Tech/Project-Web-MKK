<?php
include 'koneksi.php';
session_start();

// ambil semua produk
$result = $koneksi->query("SELECT * FROM produk");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Daftar Produk</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="../aset/css/produk.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; }
    .main-content { margin-left: 220px; padding: 20px; }
    .card img { object-fit: cover; height: 200px; }
  </style>
</head>
<body>

<!-- Sidebar (include biar konsisten) -->
<?php include 'sidebar.php'; ?>

<!-- Konten Utama -->
<div class="main-content">
  <div class="container mt-4">
    <h2 class="mb-4 text-center">Daftar Produk</h2>
    <div class="row">
      <?php while ($row = $result->fetch_assoc()): ?>
        <div class="col-md-4 mb-4">
          <div class="card h-100 shadow-sm">
            <img src="img/<?= $row['gambar'] ?>" class="card-img-top" alt="<?= $row['nama_produk'] ?>">
            <div class="card-body d-flex flex-column">
              <h5 class="card-title"><?= $row['nama_produk'] ?></h5>
              <p class="card-text text-muted">Rp<?= number_format($row['harga'], 0, ',', '.') ?></p>
              <p class="card-text small flex-grow-1"><?= substr($row['deskripsi'], 0, 100) ?>...</p>
              <a href="edit_produk.php?id=<?= $row['id_produk'] ?>" class="btn btn-primary mt-auto">Edit</a>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
