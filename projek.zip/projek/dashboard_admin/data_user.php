<?php
// data_user.php
session_start();
include 'koneksi.php';

// cek admin
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// proses reset password (form modal)
$reset_msg = '';
if (isset($_POST['reset_password'])) {
    $id_user = intval($_POST['reset_user_id']);
    $new_password = trim($_POST['new_password']);

    if ($new_password === '') {
        $reset_msg = 'Password baru tidak boleh kosong.';
    } else {
        // NOTE: menyimpan plain password agar kompatibel dengan sistem lama.
        // Untuk keamanan, sebaiknya gunakan password_hash() dan update proses login.
        $update = $koneksi->query("UPDATE user SET password = '" . $koneksi->real_escape_string($new_password) . "' WHERE id = $id_user");
        if ($update) {
            $reset_msg = 'berhasil';
        } else {
            $reset_msg = 'gagal';
        }
    }
}

// ambil semua user
$users = $koneksi->query("SELECT * FROM user ORDER BY id DESC");

// jika ada view detail
$detailUser = null;
if (isset($_GET['view'])) {
    $viewId = intval($_GET['view']);
    $detailUser = $koneksi->query("SELECT * FROM user WHERE id = $viewId")->fetch_assoc();
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Data User - Admin</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body { background: #f8f9fa; }
    .main { margin-left: 220px; padding: 28px; min-height: 100vh; }
    .card { border-radius: 12px; box-shadow: 0 4px 10px rgba(0,0,0,0.06); }
    .table thead th { vertical-align: middle; text-align: center; }
    .table td { vertical-align: middle; }
    .btn-round { border-radius: 999px; padding: 6px 14px; }
    .muted-small { font-size: .9rem; color:#6c757d; }
    .profile-box { max-width: 420px; }
  </style>
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="main">
  <div class="container-fluid">

    <div class="d-flex justify-content-between align-items-center mb-3">
      <h3 class="mb-0"> Data User</h3>
      <small class="muted-small">Total pengguna: <?= $users->num_rows ?></small>
    </div>

    <div class="row g-4">
      <!-- tabel user -->
      <div class="col-lg-8">
        <div class="card p-3">
          <div class="table-responsive">
            <table class="table table-hover align-middle">
              <thead class="table-dark">
                <tr>
                  <th style="width:60px;">No</th>
                  <th>Nama</th>
                  <th>Email</th>
                  <th>Username</th>
                  <th>No HP</th>
                  <th style="width:150px;">Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php $no = 1; while ($u = $users->fetch_assoc()): ?>
                <tr>
                  <td class="text-center"><?= $no++ ?></td>
                  <td><?= htmlspecialchars($u['nama']) ?></td>
                  <td><?= htmlspecialchars($u['email']) ?></td>
                  <td><?= htmlspecialchars($u['username'] ?? '-') ?></td>
                  <td><?= htmlspecialchars($u['hp'] ?? '-') ?></td>
                  <td class="text-center">
                    <a href="data_user.php?view=<?= $u['id'] ?>" class="btn btn-sm btn-primary btn-round">Lihat</a>

                    <!-- tombol open modal reset -->
                    <button 
                      class="btn btn-sm btn-warning btn-round"
                      data-bs-toggle="modal"
                      data-bs-target="#resetModal"
                      data-userid="<?= $u['id'] ?>"
                      data-username="<?= htmlspecialchars($u['nama'], ENT_QUOTES) ?>">
                      Reset Password
                    </button>
                  </td>
                </tr>
                <?php endwhile; ?>

                <?php if ($no === 1): // belum ada user ?>
                <tr>
                  <td colspan="6" class="text-center text-muted">Belum ada pengguna.</td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <!-- detail user -->
      <div class="col-lg-4">
        <div class="card p-3 profile-box">
          <?php if ($detailUser): ?>
            <h5 class="mb-3">Detail Pengguna</h5>
            <p><strong>Nama:</strong> <?= htmlspecialchars($detailUser['nama']) ?></p>
            <p><strong>Email:</strong> <?= htmlspecialchars($detailUser['email']) ?></p>
            <p><strong>Username:</strong> <?= htmlspecialchars($detailUser['username'] ?? '-') ?></p>
            <p><strong>No HP:</strong> <?= htmlspecialchars($detailUser['hp'] ?? '-') ?></p>
            <p><strong>Alamat:</strong><br><small class="muted-small"><?= nl2br(htmlspecialchars($detailUser['alamat'] ?? '-')) ?></small></p>
            <div class="mt-3">
              <a href="data_user.php" class="btn btn-secondary btn-sm">← Tutup</a>
              <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#resetModal"
                data-userid="<?= $detailUser['id'] ?>" data-username="<?= htmlspecialchars($detailUser['nama'], ENT_QUOTES) ?>">
                Reset Password
              </button>
            </div>
          <?php else: ?>
            <h5 class="mb-3 text-muted">Pilih pengguna</h5>
            <p class="muted-small">Klik <strong>Lihat</strong> di daftar untuk menampilkan detail pengguna di sini.</p>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Reset Password -->
<div class="modal fade" id="resetModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <form method="post" class="modal-content">
      <input type="hidden" name="reset_user_id" id="reset_user_id" value="">
      <div class="modal-header">
        <h5 class="modal-title">Reset Password</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p id="reset_user_label" class="mb-2">Reset password untuk: <strong></strong></p>

        <div class="mb-3">
          <label class="form-label">Password Baru</label>
          <input type="password" name="new_password" class="form-control" required placeholder="Masukkan password baru">
        </div>

        <div class="mb-3">
          <label class="form-label">Konfirmasi Password</label>
          <input type="password" name="confirm_password" id="confirm_password" class="form-control" required placeholder="Ketik ulang password">
          <div id="pwHelp" class="form-text text-danger d-none">Password tidak cocok.</div>
        </div>

        <div class="form-text muted-small">Catatan: sistem saat ini menyimpan password sesuai format yang ada. Untuk keamanan, sebaiknya gunakan <code>password_hash()</code> dan sesuaikan proses login.</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button type="submit" name="reset_password" id="submitReset" class="btn btn-warning">Reset Password</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>

<script>
  // isi data modal saat dibuka
  var resetModal = document.getElementById('resetModal');
  resetModal.addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget;
    var userid = button.getAttribute('data-userid');
    var username = button.getAttribute('data-username');

    document.getElementById('reset_user_id').value = userid;
    document.getElementById('reset_user_label').querySelector('strong').textContent = username;
    // reset fields
    document.querySelector('input[name=new_password]').value = '';
    document.getElementById('confirm_password').value = '';
    document.getElementById('pwHelp').classList.add('d-none');
    document.getElementById('submitReset').disabled = false;
  });

  // cek konfirmasi password sebelum submit
  var newPwEl = document.querySelector('input[name=new_password]');
  var confirmEl = document.getElementById('confirm_password');
  function checkPwMatch() {
    var pw = newPwEl.value;
    var cpw = confirmEl.value;
    var help = document.getElementById('pwHelp');
    var submit = document.getElementById('submitReset');

    if (pw !== cpw) {
      help.classList.remove('d-none');
      submit.disabled = true;
    } else {
      help.classList.add('d-none');
      submit.disabled = false;
    }
  }
  newPwEl.addEventListener('input', checkPwMatch);
  confirmEl.addEventListener('input', checkPwMatch);
</script>

<?php
// tampilkan notifikasi hasil reset
if ($reset_msg === 'berhasil') {
    echo "<script>Swal.fire({icon:'success', title:'Sukses', text:'Password berhasil direset'});</script>";
} elseif ($reset_msg === 'gagal') {
    echo "<script>Swal.fire({icon:'error', title:'Gagal', text:'Reset password gagal'});</script>";
} elseif ($reset_msg !== '' && $reset_msg !== 'berhasil' && $reset_msg !== 'gagal') {
    echo "<script>Swal.fire({icon:'warning', title:'Perhatian', text:'". addslashes($reset_msg) ."'});</script>";
}
?>

</body>
</html>
