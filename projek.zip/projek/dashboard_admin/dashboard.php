<?php
include 'koneksi.php';
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

// Hapus produk
if (isset($_GET['hapus'])) {
    $id = $_GET['hapus'];
    $ambil = $koneksi->query("SELECT gambar FROM produk WHERE id_produk = $id");
    $row = $ambil->fetch_assoc();
    if ($row['gambar'] && file_exists("img/" . $row['gambar'])) {
        unlink("img/" . $row['gambar']);
    }
    $koneksi->query("DELETE FROM produk WHERE id = $id");
    header("Location: dashboard.php?status=hapus");
    exit();
}

// Tambah produk
if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];
    $stok = $_POST['stok'];
    $id_kategori = $_POST['id_kategori'];
    $deskripsi = $_POST['deskripsi'];

    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];
    $folder = 'img/' . $gambar;
    move_uploaded_file($tmp, $folder);

    $koneksi->query("INSERT INTO produk (nama_produk, harga, stok, id_kategori, deskripsi, gambar) 
                     VALUES ('$nama', '$harga', '$stok', '$id_kategori', '$deskripsi', '$gambar')");
    header("Location: dashboard.php?status=tambah");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body { background: #f8f9fa; }
    .content { margin-left: 260px; padding: 20px; }
    img { width: 70px; height: 70px; object-fit: cover; border-radius: 6px; }
    .btn-purple { background-color: #6f42c1; color: #fff; }
    .btn-purple:hover { background-color: #5936a2; }
    .table thead th { text-align: center; }
    .table td, .table th { vertical-align: middle; }
  </style>
</head>
<body>

<?php include 'sidebar.php'; ?>

<div class="content">
  <h2 class="mb-4">Dashboard Admin</h2>

  <!-- ALERT SWEETALERT -->
  <?php if (isset($_GET['status'])): ?>
    <script>
      document.addEventListener("DOMContentLoaded", function() {
          <?php if ($_GET['status'] == 'tambah'): ?>
              Swal.fire({ icon: 'success', title: 'Berhasil!', text: 'Produk berhasil ditambahkan', confirmButtonColor: '#28a745' });
          <?php elseif ($_GET['status'] == 'hapus'): ?>
              Swal.fire({ icon: 'warning', title: 'Dihapus!', text: 'Produk berhasil dihapus', confirmButtonColor: '#d33' });
          <?php endif; ?>
      });
    </script>
  <?php endif; ?>

  <!-- FORM TAMBAH PRODUK -->
  <div class="card p-4 mb-4 shadow-sm">
    <h4 class="mb-3">Tambah Produk</h4>
    <form method="post" enctype="multipart/form-data">
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">Nama Produk</label>
          <input type="text" name="nama" class="form-control" required>
        </div>
        <div class="col-md-3 mb-3">
          <label class="form-label">Harga</label>
          <input type="number" name="harga" class="form-control" required>
        </div>
        <div class="col-md-3 mb-3">
          <label class="form-label">Stok</label>
          <input type="number" name="stok" class="form-control" required>
        </div>
      </div>
      <div class="mb-3">
        <label class="form-label">Kategori</label>
        <select name="id_kategori" class="form-select" required>
          <option value="">-- Pilih Kategori --</option>
          <?php
          $kategori_q = mysqli_query($koneksi, "SELECT * FROM kategori");
          while ($row = mysqli_fetch_assoc($kategori_q)) {
            echo "<option value='{$row['id_kategori']}'>{$row['nama_kategori']}</option>";
          }
          ?>
        </select>
      </div>
      <div class="mb-3">
        <label class="form-label">Deskripsi</label>
        <textarea name="deskripsi" class="form-control" rows="3" required></textarea>
      </div>
      <div class="mb-3">
        <label class="form-label">Gambar</label>
        <input type="file" name="gambar" class="form-control" required>
      </div>
      <button type="submit" name="tambah" class="btn btn-purple">Tambah Produk</button>
    </form>
  </div>

  <!-- TABEL PRODUK -->
  <div class="card shadow-sm p-3">
    <h4 class="mb-3">Daftar Produk</h4>
    <div class="table-responsive">
      <table class="table table-bordered table-striped text-center align-middle">
        <thead class="table-dark">
          <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Kategori</th>
            <th>Deskripsi</th>
            <th>Gambar</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          $no = 1;
          $result = $koneksi->query("SELECT p.*, k.nama_kategori 
                                     FROM produk p
                                     JOIN kategori k ON p.id_kategori = k.id_kategori");
          while ($row = $result->fetch_assoc()):
          ?>
          <tr>
            <td><?= $no++ ?></td>
            <td><?= $row['nama_produk'] ?></td>
            <td>Rp<?= number_format($row['harga']) ?></td>
            <td><?= number_format($row['stok']) ?></td>
            <td><?= $row['nama_kategori'] ?></td>
            <td><?= $row['deskripsi'] ?></td>
            <td>
              <?php if ($row['gambar']): ?>
                <img src="img/<?= $row['gambar'] ?>" alt="gambar">
              <?php else: ?>
                <span class="text-muted">Tidak ada</span>
              <?php endif; ?>
            </td>
            <td>
              <a href="edit.php?id=<?= $row['id_produk'] ?>" class="btn btn-sm btn-success">Edit</a>
              <a href="?hapus=<?= $row['id_produk'] ?>" onclick="return confirm('Hapus produk ini?')" class="btn btn-sm btn-danger">Hapus</a>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>

</div>
</body>
</html>
