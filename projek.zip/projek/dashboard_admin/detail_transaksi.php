<?php
include 'koneksi.php';
include 'sidebar.php';

if (!isset($_GET['id'])) {
    echo "ID Transaksi tidak ditemukan.";
    exit;
}

$id_transaksi = intval($_GET['id']);

// Ambil data transaksi
$transaksi = $koneksi->query("
    SELECT t.id_transaksi, t.tanggal, u.nama, t.total_harga
    FROM transaksi t
    JOIN user u ON t.id_pelanggan = u.id
    WHERE t.id_transaksi = $id_transaksi
")->fetch_assoc();

// Ambil detail produk
$queryDetail = $koneksi->query("
    SELECT p.nama_produk, d.jumlah, p.harga, (d.jumlah * p.harga) AS subtotal
    FROM detail d
    JOIN produk p ON d.id_produk = p.id_produk
    WHERE d.id_transaksi = $id_transaksi
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Detail Transaksi</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    .main {
      margin-left: 220px;
      padding: 30px;
      background: #f9f9f9;
      min-height: 100vh;
    }
    .card {
      border-radius: 12px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
  </style>
</head>
<body>
<div class="main">

  <div class="card">
    <div class="card-header bg-dark text-white">
      <h4 class="mb-0">Detail Transaksi #<?= $transaksi['id_transaksi'] ?></h4>
    </div>
    <div class="card-body">
      <p><strong>Tanggal:</strong> <?= date('d-m-Y', strtotime($transaksi['tanggal'])) ?></p>
      <p><strong>Nama Pelanggan:</strong> <?= $transaksi['nama'] ?></p>
      <p><strong>Total:</strong> Rp <?= number_format($transaksi['total_harga'],0,',','.') ?></p>

      <div class="table-responsive mt-4">
        <table class="table table-bordered table-hover">
          <thead class="table-dark text-center">
            <tr>
              <th>Produk</th>
              <th>Jumlah</th>
              <th>Harga</th>
              <th>Subtotal</th>
            </tr>
          </thead>
          <tbody>
            <?php while($row = $queryDetail->fetch_assoc()): ?>
            <tr>
              <td><?= $row['nama_produk'] ?></td>
              <td class="text-center"><?= $row['jumlah'] ?></td>
              <td class="text-end">Rp <?= number_format($row['harga'],0,',','.') ?></td>
              <td class="text-end">Rp <?= number_format($row['subtotal'],0,',','.') ?></td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>

      <!-- Tombol Back -->
      <a href="data_transaksi.php" class="btn btn-secondary mt-3">← Kembali</a>
    </div>
  </div>

</div>
</body>
</html>
