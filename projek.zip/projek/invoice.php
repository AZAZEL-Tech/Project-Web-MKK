<?php
session_start();

$koneksi = mysqli_connect("localhost", "root", "", "kichen");
$id       = $_GET['id'];
$id_user  = $_SESSION['id_user'];

// Ambil transaksi untuk header
$trans = "SELECT * FROM detail
          INNER JOIN transaksi ON detail.id_transaksi = transaksi.id_transaksi
          WHERE detail.id_transaksi = '$id'";
$query = mysqli_query($koneksi, $trans);
$data  = mysqli_fetch_array($query);

// Ambil data user & transaksi
$res = "SELECT * FROM transaksi
        INNER JOIN user ON transaksi.id_pelanggan = user.id
        WHERE transaksi.id_transaksi = '$id'
          AND transaksi.id_pelanggan = '$id_user'";
$query = mysqli_query($koneksi, $res);
$user  = mysqli_fetch_array($query);
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Invoice</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  <style>
    body {
      background: #f8f9fa;
    }
    .invoice-card {
      border-radius: 15px;
      overflow: hidden;
    }
    .invoice-header {
      background: #198754;
      color: white;
      padding: 20px;
    }
    .invoice-header h2 {
      margin: 0;
    }
    .table th {
      background: #343a40;
      color: white;
    }
    .total-row td {
      font-weight: bold;
      background: #f1f1f1;
    }
    .btn-print {
      margin-top: 20px;
    }
  </style>
</head>
<body>

<div class="container py-5">
  <div class="card shadow-lg invoice-card">
    <!-- Header -->
    <div class="invoice-header text-center">
      <h2><i class="bi bi-receipt-cutoff"></i> Invoice</h2>
      <p class="mb-0">No. Invoice: <strong>INV-<?= $id ?></strong></p>
    </div>

    <div class="card-body p-4">
      <!-- Info -->
      <div class="row mb-4">
        <div class="col-md-6">
          <h6>Pembeli:</h6>
          <p><strong><?= $user['nama'] ?></strong></p>
        </div>
        <div class="col-md-6 text-md-end">
          <h6>Tanggal:</h6>
          <p><?= date("d/m/Y", strtotime($data['tanggal'])) ?></p>
        </div>
      </div>

      <!-- Table -->
      <div class="table-responsive">
        <table class="table table-bordered text-center align-middle">
          <thead>
            <tr>
              <th>Nama Barang</th>
              <th>Qty</th>
              <th>Harga</th>
              <th>Subtotal</th>
            </tr>
          </thead>
          <tbody>
          <?php
          $prod = "SELECT detail.*, produk.nama_produk, produk.harga 
         FROM detail
         INNER JOIN produk ON detail.id_produk = produk.id_produk
         WHERE detail.id_transaksi = '$id'";
$query2 = mysqli_query($koneksi, $prod);

while ($row = mysqli_fetch_array($query2)) {
    $subtotal = $row['jumlah'] * $row['harga'];
    ?>
    <tr>
        <td class="text-start"><?= $row['nama_produk'] ?></td>
        <td><?= $row['jumlah'] ?></td>
        <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
        <td>Rp <?= number_format($subtotal, 0, ',', '.') ?></td>
    </tr>
<?php } ?>
            <tr class="total-row">
              <td colspan="3" class="text-end">Grand Total</td>
              <td>Rp <?= number_format($data['total_harga'], 0, ',', '.') ?></td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Tombol -->
      <div class="text-center">
        <button onclick="window.print()" class="btn btn-primary btn-lg btn-print">
          <i class="bi bi-printer"></i> Cetak Invoice
        </button>
        <a href="index.php" class="btn btn-outline-secondary btn-lg btn-print">
          <i class="bi bi-shop"></i> Kembali Belanja
        </a>
      </div>
    </div>
  </div>
</div>

</body>
</html>

