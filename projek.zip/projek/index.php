<?php
include 'koneksi.php';
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Beranda</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #fff;
    }

    .navbar-brand img {
      height: 40px;
    }

    .carousel-caption {
      text-align: left;
      left: 10%;
      right: auto;
      bottom: 20%;
    }

    .carousel-caption h1 {
      font-weight: 800;
      color: #3c2e1f;
    }

    .carousel-caption p {
      font-size: 1rem;
      color: #555;
    }

    .btn-warning {
      background-color: #f4b400;
      border: none;
      font-weight: bold;
    }

    .card h4 {
      font-weight: bold;
    }

    .card .kategori {
      font-size: 0.9rem;
      font-weight: 600;
      color: #6c757d;
      margin-bottom: 8px;
    }

    .card .harga {
      font-size: 1.1rem;
      font-weight: bold;
      color: #198754;
    }
  </style>
</head>
<body>

<!-- NAVBAR -->
<?php include 'navbar.php'; ?>

<!-- CAROUSEL -->
<style>
  #carouselExampleCaptions {
    max-width: 1400px;
    margin: 100px auto;
  }

  #carouselExampleCaptions .carousel-item img {
    height: 400px;
    object-fit: cover;
    border-radius: 10px;
  }
</style>

<div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"></button>
  </div>

  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="aset/img/cumi_pedas.jpg" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/gurame_bakar.png" class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="img/gulai_cumi.png" class="d-block w-100" alt="...">
    </div>
  </div>

  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

<?php
$result = $koneksi->query("SELECT * FROM produk");
?>

<div class="container mt-4">
  <div class="row">
    <?php while ($row = $result->fetch_assoc()): ?>
      <div class="col-md-4 mb-4">
        <div class="card h-100">
          <img src="aset/img/<?= $row['gambar'] ?>" class="card-img-top" alt="<?= $row['nama_produk'] ?>" style="object-fit: cover; height: 300px;">
          <div class="card-body d-flex flex-column">
            <h4><?= $row['nama_produk'] ?></h4>
            <p class="kategori">Kategori: <?= $row['id_kategori'] ?></p>
            <p class="harga">Rp <?= number_format($row['harga'], 0, ',', '.') ?></p>
            <p class="card-text mb-3"><?= $row['deskripsi'] ?></p>
            <a href="detail.php?id=<?= $row['id_produk'] ?>" class="btn btn-primary mt-auto">Beli</a>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</body>
</html>
