<?php
// Koneksi ke database
$koneksi = mysqli_connect("localhost", "root", "", "kichen");

// Cek koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Proses simpan data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama     = $_POST['nama'];
    $email    = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password']; // langsung disimpan tanpa hash
    $hp    = preg_replace('/[^0-9]/', '', $_POST['hp']); // hanya angka
    $alamat   = $_POST['alamat'];
    $role     = "user"; // otomatis user

    // Cek email atau username sudah terdaftar
    $cek = mysqli_query($koneksi, "SELECT * FROM user WHERE email='$email' OR username='$username'");
    if (mysqli_num_rows($cek) > 0) {
        echo "<div class='alert alert-danger text-center'>Email atau Username sudah terdaftar!</div>";
    } else {
        $query = "INSERT INTO user (nama, email, username, password, hp, alamat, role) 
                  VALUES ('$nama', '$email', '$username', '$password', '$hp', '$alamat', '$role')";

        if (mysqli_query($koneksi, $query)) {
            echo "<div class='alert alert-success text-center'>Registrasi berhasil! Role: $role</div>";
        } else {
            echo "<div class='alert alert-danger text-center'>Error: " . mysqli_error($koneksi) . "</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Registrasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow-lg">
        <div class="card-header bg-primary text-white text-center">
            <h3>Form Registrasi</h3>
        </div>
        <div class="card-body">
            <form method="POST" action="">
                
                <div class="mb-3">
                    <label for="nama" class="form-label">Nama Lengkap</label>
                    <input type="text" name="nama" id="nama" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" name="email" id="email" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" name="username" id="username" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" name="password" id="password" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="hp" class="form-label">Nomor HP</label>
                    <input type="tel" name="hp" id="hp" class="form-control" placeholder="081234567890" required>
                </div>

                <div class="mb-3">
                    <label for="alamat" class="form-label">Alamat</label>
                    <textarea name="alamat" id="alamat" class="form-control" rows="3" required></textarea>
                </div>

                <button type="submit" class="btn btn-success w-100">Daftar</button>
            </form>
        </div>
    </div>
</div>

</body>
</html>
