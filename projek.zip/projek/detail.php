<?php
session_start();
include 'koneksi.php';


// Cek apakah ada id di URL
if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "Produk tidak ditemukan!";
    exit;
}

$id = intval($_GET['id']); // pastikan tipe integer

// Ambil data produk berdasarkan id
$stmt = $koneksi->prepare("SELECT * FROM produk WHERE id_produk = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Produk tidak ditemukan!";
    exit;
}

$produk = $result->fetch_assoc();

// Ambil produk rekomendasi (kategori sama, id berbeda)
$stmt_rekom = $koneksi->prepare("SELECT * FROM produk WHERE id_kategori = ? AND id_produk != ? LIMIT 4");
$stmt_rekom->bind_param("si", $produk['kategori'], $id);
$stmt_rekom->execute();
$rekom_result = $stmt_rekom->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Produk - <?= $produk['nama_produk'] ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .product-card img {
            height: 200px;
            object-fit: cover;
        }
        .product-card {
            transition: 0.3s;
        }
        .product-card:hover {
            transform: scale(1.02);
        }
    .product-card img {
        height: 200px;
        object-fit: cover;
    }
    .product-card {
        transition: 0.3s;
    }
    .product-card:hover {
        transform: scale(1.02);
    }
    /* Ukuran gambar utama di detail */
    .main-product-img {
        max-height: 200px;
        object-fit: cover;
        border-radius: 10px;
    }
</style>

</head>
<body>
    <?php include 'navbar.php'; ?>

<div class="container mt-5">
    
    <!-- Detail Produk -->
    <div class="row mb-5">
        <div class="col-md-6">
            <img src="aset/img/<?= $produk['gambar'] ?>" class="img-fluid rounded" alt="<?= $produk['nama_produk'] ?>">
        </div>
        <div class="col-md-6">
            <h2><?= $produk['nama_produk'] ?></h2>
            <h4 class="text-danger">Rp<?= number_format($produk['harga'], 0, ',', '.') ?></h4>
            <p>
                <span class="badge <?= $produk['stok'] > 0 ? 'bg-success' : 'bg-danger' ?>">
                    <?= $produk['stok'] > 0 ? 'Stok tersedia (' . $produk['stok'] . ')' : 'Stok habis' ?>
                </span>
            </p>
            <p><strong>Kategori:</strong> <?= $produk['kategori'] ?></p>
            <p><?= $produk['deskripsi'] ?></p>
            <div class="mt-4">
                <a href="index.php" class="btn btn-secondary me-2">
                    <i class="bi bi-arrow-left"></i> Kembali
                </a>
                <form method="post" action="cart.php?id=<?= $produk['id_produk']; ?>">
    <input type="hidden" name="hidden_nama" value="<?= $produk['nama_produk']; ?>">
    <input type="hidden" name="hidden_harga" value="<?= $produk['harga']; ?>">
    <input type="hidden" name="hidden_gambar" value="<?= $produk['gambar']; ?>">
    <input type="number" name="jumlah" value="1" min="1">
    <button type="submit" name="add" class="btn btn-primary">Tambah ke Keranjang</button>
</form>

            </div>
        </div>
    </div>
        </div>
    </div>

    <!-- Rekomendasi Produk -->
    <?php if ($rekom_result->num_rows > 0): ?>
    <h4 class="mb-4">Produk Lainnya di Kategori Ini</h4>
    <div class="row">
        <?php while ($row = $rekom_result->fetch_assoc()): ?>
        <div class="col-md-3 mb-4">
            <div class="card product-card h-70">
                <img src="aset/img/<?= $row['gambar'] ?>" class="card-img-top" alt="<?= $row['nama_produk'] ?>">
                <div class="card-body">
                    <h5 class="card-title"><?= $row['nama_produk'] ?></h5>
                    <p class="text-danger mb-1">Rp<?= number_format($row['harga'], 0, ',', '.') ?></p>
                    <a href="detail.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-primary">Lihat Detail</a>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
    <?php endif; ?>
</div>

</body>
</html>
